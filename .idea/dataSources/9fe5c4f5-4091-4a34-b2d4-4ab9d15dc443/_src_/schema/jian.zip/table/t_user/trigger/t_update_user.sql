CREATE TRIGGER t_update_user
BEFORE UPDATE ON t_user
FOR EACH ROW
  BEGIN
set new.name = UPPER(new.name);
end;
