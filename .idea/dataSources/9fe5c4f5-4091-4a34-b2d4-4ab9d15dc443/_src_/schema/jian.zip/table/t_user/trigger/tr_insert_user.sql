CREATE TRIGGER tr_insert_user
BEFORE INSERT ON t_user
FOR EACH ROW
  BEGIN
insert into t_stu (name,PASSWORD) values (new.name,new.password);
end;
