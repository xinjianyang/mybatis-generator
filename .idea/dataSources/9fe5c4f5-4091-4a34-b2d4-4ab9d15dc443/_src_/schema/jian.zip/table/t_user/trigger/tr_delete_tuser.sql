CREATE TRIGGER tr_delete_tuser
AFTER DELETE ON t_user
FOR EACH ROW
  BEGIN
delete from t_stu where name = old.name; 
end;
