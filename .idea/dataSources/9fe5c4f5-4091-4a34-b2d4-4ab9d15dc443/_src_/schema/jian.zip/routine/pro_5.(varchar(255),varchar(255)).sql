CREATE PROCEDURE pro_5(IN stuname VARCHAR(255), IN stupassword VARCHAR(255))
  begin 
insert into t_stu (name, password) values (stuname, stupassword);
end;
