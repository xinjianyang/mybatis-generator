CREATE PROCEDURE pro_2(OUT price DECIMAL(8, 2))
  BEGIN
select prod_price into price from products where prod_id = ANV01;
END;
