CREATE PROCEDURE pro_1(OUT price DECIMAL(8, 2))
  BEGIN
select prod_price into price from products;
END;
