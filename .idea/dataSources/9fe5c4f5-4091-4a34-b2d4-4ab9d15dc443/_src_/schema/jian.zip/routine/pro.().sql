CREATE PROCEDURE pro()
  BEGIN
select MAX(prod_price) from products;
end;
